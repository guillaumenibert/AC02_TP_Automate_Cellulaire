# ATOMICCELLU - LG Corporation (c) - Projet AC02

Création d'un automate cellulaire en C, comprenant les fonctionnalités décrites dans le TP.

Après compilation du programme, ouvrez une invite de commande `cmd` et déplacez vous dans le répertoire où se situe le programme `ATOMICCELLU.exe` et le dossier de sauvegardes `sauvegardes`.

Lancez le programme avec les paramètres voulus (`-load` ou `-new`) :

#### Paramètre `-new`
Pour créer une nouvelle grille on utilise le paramètre `-new` :

Lancez `start_new.bat`

#### Paramètre `-load`
Pour charger une grille sauvegardée au format `.txt` dans le répertoire `sauvegardes`, on utilise le paramètre `-load` :

Lancez `start_load.bat`

## Licence

[MIT](https://github.com/MCDoors/AC02_TP_Automate_Cellulaire/blob/master/LICENSE)